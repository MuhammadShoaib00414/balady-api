<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Authentication Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used during authentication for various
    | messages that we need to display to the user. You are free to modify
    | these language lines according to your application's requirements.
    |
    */

    'Dashboard' => 'اللوحة الرئيسية',
    'Course categories'=>'فئات الدورة',
    'Courses'=>'الدورات',
    'Organization'=>'منظمة',
    'Sub Admin'=>'المشرف الفرعي',
    'Trainer'=>'مدرب',
    'Candidates'=>'مرشحين', 
    'Number courses'=>'عدد الدورات',
    'Number of trainers'=>'عدد المدربين',
    'Number of categories'=>'عدد الفئات',
    'Number of question'=>'عدد السؤال',
    'Add new category'=>'إضافة فئة جديدة',
    'Sub categories'=>'الفئات الفرعية',
    'Edit'=>'تعديل',
    'Are you sure?'=>'هل أنت متأكد؟',
    'No, cancel it'=>'لا ، قم بإلغائها',
    'Yes, delete it'=>'نعم ، احذفهاt',
    'You will not be able to undo this action!'=>'لن تتمكن من التراجع عن هذا الإجراء!',
    'Back to Courses Categories'=>'العودة إلى فئات الدورات',
    'Category Add Form'=>'فئة إضافة نموذج',
    'Submit'=>'إرسال',
    'Title'=>'عنوان',
    'Category'=>'فئة',
    'Lesson and section'=>'الدرس والقسم',
    'Enrolled student'=>'طالب مسجل',
    'Status'=>'حالة',
    'Instructor'=>'معلم',
    'Action'=>'عمل',
    'Total section'=>'قسم المجموع',
    'Total lesson'=>'مجموع الدرس',
    'Total enrolment'=>'إجمالي عدد المسجلين',
    'edit'=>'تعديل',
    'Active'=>'نشيط',
    'Deactive'=>'معطل',
    'Categories'=>'التصنيفات',
    'Pending'=>'قيد الانتظار',
    'View course on frontend'=>'عرض الدورة على الواجهة الأمامية',
    'Mark as Active'=>'وضع علامة نشط',
    'Mark as pending'=>'وضع علامة معلق',
    'Delete'=>'حذف',
    'Curriculum'=>'مقرر',
    'Basic'=>'أساسي',
    'Requirements'=>'متطلبات',
    'Outcomes'=>'النتائج',
    'Media'=>'وسائط',
    'Finish'=>'ينهي',
    'Add section'=>'إضافة قسم',
    'Add Lesson'=>'أضف درسًا',
    'Add quiz'=>'إضافة اختبار',
    'Certificate'=>'شهادة',
    'Final Exam'=>'إمتحان نهائي',
];
