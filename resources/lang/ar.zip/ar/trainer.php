<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Authentication Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used during authentication for various
    | messages that we need to display to the user. You are free to modify
    | these language lines according to your application's requirements.
    |
    */

    'Courses' => 'الدورات',
    'Add Test' => 'أضف اختبار',
    'Students' => 'الطلاب',
    'Virtual Class-room' => 'الفصول الافتراضية',
    'Training Calendar' => 'تقويم التدريب',
    'My profile' => 'ملفي',
    'Number courses'=>'عدد الدورات',
    'Number of organizations'=>'تنظیموں کی تعداد',
    'Number of student'=>'عدد الطلاب',
    'Dashboard'=>'لوحة القيادة',
    'Add new course'=>'إضافة دورة جديدة',
    'Title'=>'عنوان',
    'Category'=>'فئة',
    'Lesson and section'=>'الدرس والقسم',
    'Enrolled student'=>'طالب مسجل',
    'Status'=>'حالة',
    'Action'=>'عمل',
    'Total section'=>'قسم المجموع',
    'Total lesson'=>'مجموع الدرس',
    'Total enrolment'=>'إجمالي عدد المسجلين',
    'edit'=>'تعديل',
    'Active'=>'نشيط',
    'Deactive'=>'معطل',
];
